<?php
declare(strict_types = 1);
include __DIR__.'/vendor/autoload.php';
include __DIR__.'/conf.php';
error_reporting(E_ALL);
ini_set('display_errors', '1');