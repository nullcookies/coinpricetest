<?php
// Database Settings
define('DB_SERVER', "localhost");           // Database Host
define('DB_USER', "root");                  // Databse User
define('DB_PASS', "Tanthanh");                      // Database Password
define('DB_DATABASE', "teamta_bot");   		// Database Name
?>